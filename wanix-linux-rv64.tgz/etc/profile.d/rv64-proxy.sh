if grep -qw 'rv64.network=fetch' /proc/cmdline 2>/dev/null; then
    export http_proxy=http://10.0.2.2:8080
    export https_proxy=http://10.0.2.2:8080
    export HTTP_PROXY="$http_proxy"
    export HTTPS_PROXY="$https_proxy"
else
    unset http_proxy https_proxy HTTP_PROXY HTTPS_PROXY
fi
